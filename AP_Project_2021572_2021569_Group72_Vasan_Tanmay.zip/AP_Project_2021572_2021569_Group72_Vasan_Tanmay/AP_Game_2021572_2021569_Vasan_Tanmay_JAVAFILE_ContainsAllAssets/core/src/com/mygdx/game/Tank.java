package com.mygdx.game;

import java.io.Serializable;
import java.util.ArrayList;

public class Tank implements Serializable {

    private static class Missiles{
        int power;
        int damage;
        int speed;

        public Missiles(int power, int damage, int speed) {
            this.power = power;
            this.damage = damage;
            this.speed = speed;
        }
    }

    private String name;
    private int BHP;
    private String colour;

    String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public int getBHP() {
        return BHP;
    }

    public void setBHP(int BHP) {
        this.BHP = BHP;
    }
    public String getColour() {
        return colour;
    }

    public void setColour(String colour) {
        this.colour = colour;
    }

    Tank(int BHP, String colour, String name){
        this.BHP = BHP;
        this.name = name;
        this.colour = colour;
    }


}
