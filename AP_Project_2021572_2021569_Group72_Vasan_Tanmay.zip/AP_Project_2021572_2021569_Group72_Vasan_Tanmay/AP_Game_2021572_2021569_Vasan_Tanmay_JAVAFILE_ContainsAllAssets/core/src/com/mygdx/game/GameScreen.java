package com.mygdx.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.Drawable;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

public class GameScreen implements Screen {

	private static class Movement_in_terrain{
		int range;
		String Terrain;
		int speed_in_terrain;

		public Movement_in_terrain(int range, String terrain, int speed_in_terrain) {
			this.range = range;
			Terrain = terrain;
			this.speed_in_terrain = speed_in_terrain;
		}
	}

	private static class drops{
		int value;
		String name;

		public drops(int value, String name) {
			this.value = value;
			this.name = name;
		}
	}
	private static class fire{
		float angle;
		float power;

		public fire(float angle, float power) {
			this.angle = angle;
			this.power = power;
		}
	}



	private TankStar game;
	private Texture img_entry_screen;
	private Sprite sprite_entry_button;
	private Stage stage;
	private Skin skin;
	private TextButton textButton;
	private Texture buttonTexture;
	private Drawable drawable;
	private ImageButton imageButton;

	GameScreen(TankStar game){
		this.game=game;
		stage = new Stage(new ScreenViewport());
		img_entry_screen = new Texture("GameScreen.jpg");

		buttonTexture = new Texture(Gdx.files.internal("Menu.jpg"));
		drawable = new TextureRegionDrawable(new TextureRegion(buttonTexture));
		imageButton = new ImageButton(drawable);
		imageButton.setBounds(0, 440, 120, 100);

		stage.addActor(imageButton);
		Gdx.input.setInputProcessor(stage);
	}


	@Override
	public void show() {


	}

	@Override
	public void render(float delta) {
		ScreenUtils.clear(0, 0, 0, 1);
		game.batch.begin();
		game.batch.draw(img_entry_screen, 0, 0);
		game.batch.end();
		stage.draw();

		imageButton.addListener(new ClickListener(){
			                        @Override
			                        public void clicked(InputEvent event, float x, float y) {
				                        game.setScreen(new MenuOnGameScreen(game));
			                        }
		                        }
		)
		;
	}

	@Override
	public void resize(int width, int height) {

	}

	@Override
	public void pause() {

	}

	@Override
	public void resume() {

	}

	@Override
	public void hide() {

	}

	@Override
	public void dispose() {
		img_entry_screen.dispose();
		stage.dispose();
	}
}