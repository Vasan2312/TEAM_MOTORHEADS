package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.Drawable;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

public class DailyMission implements  Screen{

    private TankStar game;
    private Texture img_entry_screen,daily_mission_menu,back_it;
    private TextureRegion ImageRegion;
    private Stage stage;
    private Drawable drawable;
    private ImageButton imageButton;
    DailyMission(TankStar game)
    {
        this.game=game;

        stage = new Stage(new ScreenViewport());
//        img_entry_screen=new Texture("Dull_bg.jpeg");

        daily_mission_menu=new Texture("DailyTab.jpg");
        ImageRegion = new TextureRegion(daily_mission_menu, 0, 0, 1161, 536);

        back_it= new Texture(Gdx.files.internal("Back.jpg"));
        drawable = new TextureRegionDrawable(new TextureRegion(back_it));
        imageButton = new ImageButton(drawable);
        imageButton.setBounds(360, 309, 84, 84);

        stage.addActor(imageButton);
        Gdx.input.setInputProcessor(stage);
    }

    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0, 0, 0, 1);
        game.batch.begin();
        game.batch.draw(daily_mission_menu, 0, 0);
        game.batch.end();
        stage.draw();

        imageButton.addListener(new ClickListener(){
                                    @Override
                                    public void clicked(InputEvent event, float x, float y) {
                                        game.setScreen(new MainMenu(game));
                                        stage.dispose();
                                    }
                                }
        )
        ;
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {


    }
}