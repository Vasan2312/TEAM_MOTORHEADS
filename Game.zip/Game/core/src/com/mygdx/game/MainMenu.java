package com.mygdx.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.Drawable;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

import java.io.IOException;

public class MainMenu implements Screen {

    private TankStar game;
    private Texture img_entry_screen,img_entry_button;
    private Sprite sprite_entry_button;
    private Stage stage;
    private Skin skin;
    private TextButton textButton;
    private Texture buttonTexture,daily_mission_button,vs_friend,resume,exit;
    private Drawable drawable,drawable1,drawable2,drawable3,drawable4;
    private ImageButton imageButton,imageButton1,imageButton3,imageButton2,imageButton4;



    MainMenu(TankStar game){
        this.game=game;
        stage = new Stage(new ScreenViewport());
        img_entry_screen = new Texture("MainMenu.jpg");

        buttonTexture = new Texture(Gdx.files.internal("SettingButton.jpg"));
        drawable = new TextureRegionDrawable(new TextureRegion(buttonTexture));
        imageButton = new ImageButton(drawable);
        imageButton.setBounds(15, 449, 79, 79);

        daily_mission_button= new Texture(Gdx.files.internal("DailyMission.jpg"));
        drawable1 = new TextureRegionDrawable(new TextureRegion(daily_mission_button));
        imageButton1 = new ImageButton(drawable1);
        imageButton1.setBounds(2, 329, 101, 82);

        vs_friend= new Texture(Gdx.files.internal("New_game.jpg"));
        drawable2 = new TextureRegionDrawable(new TextureRegion(vs_friend));
        imageButton2 = new ImageButton(drawable2);
        imageButton2.setBounds(707, 389, 427, 113);

        resume= new Texture(Gdx.files.internal("Resume.jpg"));
        drawable3 = new TextureRegionDrawable(new TextureRegion(resume));
        imageButton3 = new ImageButton(drawable3);
        imageButton3.setBounds(707, 212, 427, 113);

        exit= new Texture(Gdx.files.internal("exit.jpg"));
        drawable4 = new TextureRegionDrawable(new TextureRegion(exit));
        imageButton4 = new ImageButton(drawable4);
        imageButton4.setBounds(702, 36, 427, 113);

        stage.addActor(imageButton);
        stage.addActor(imageButton1);
        stage.addActor(imageButton2);
        stage.addActor(imageButton3);
        stage.addActor(imageButton4);
        Gdx.input.setInputProcessor(stage);
    }


    @Override
    public void show() {


    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0, 0, 0, 1);
        game.batch.begin();
        game.batch.draw(img_entry_screen, 0, 0);
        game.batch.end();
        stage.draw();

        imageButton.addListener(new ClickListener(){
                                    @Override
                                    public void clicked(InputEvent event, float x, float y) {
                                        if(game.flag==0) {
                                            game.setScreen(new Setting(game));
                                            stage.dispose();
                                        }
                                        else if(game.flag==1) {
                                            game.setScreen(new Setting1(game));
                                            stage.dispose();
                                        }
                                        else if(game.flag==2) {
                                            game.setScreen(new Setting2(game));
                                            stage.dispose();
                                        }
                                        else if(game.flag==3) {
                                            game.setScreen(new Setting3(game));
                                            stage.dispose();
                                        }

                                    }
                                }
        )
        ;

        imageButton1.addListener(new ClickListener(){
                                     @Override
                                     public void clicked(InputEvent event, float x, float y) {
                                         game.setScreen(new DailyMission(game));
                                         stage.dispose();
                                     }
                                 }
        )
        ;
        imageButton4.addListener(new ClickListener(){
                                     @Override
                                     public void clicked(InputEvent event, float x, float y) {
                                         game.setScreen(new Exit(game));
                                         stage.dispose();
                                     }
                                 }
        )
        ;
        imageButton3.addListener(new ClickListener(){
                                     @Override
                                     public void clicked(InputEvent event, float x, float y) {
                                         game.setScreen(new DailyMission(game));
                                         stage.dispose();
                                     }
                                 }
        )
        ;

        imageButton2.addListener(new ClickListener(){
                                     @Override
                                     public void clicked(InputEvent event, float x, float y) {
                                         game.setScreen(new Tank_select1(game));
                                         stage.dispose();
                                     }
                                 }
        )
        ;
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        img_entry_screen.dispose();
        stage.dispose();
    }
}