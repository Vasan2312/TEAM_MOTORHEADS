package com.mygdx.game.Sprites;

import com.badlogic.gdx.graphics.g2d.Sprite;

public class Tanks extends Sprite {

	/*
	public World world;
	public Body b2body;

	public Tanks(World world)
	{
		this.world=world;
		 defineTank();
	}

	public void defineTank()
	{
		BodyDef bdef =new BodyDef();
		FixtureDef fdef= new FixtureDef();
		CircleShape shape=new CircleShape();
		shape.setRadius(4/TankStar.Pixel);

		fdef.shape=shape;

		bdef.type = BodyDef.BodyType.DynamicBody;
		bdef.position.set(21/TankStar.Pixel ,21/TankStar.Pixel);
		b2body= world.createBody(bdef);

		b2body.createFixture(fdef);
	}
	 */
}