<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="tankystar.jpp copy" tilewidth="1" tileheight="1" tilecount="810000" columns="1200">
 <image source="/Users/varul18/Desktop/Game/assets/tankystar.jpg" width="1200" height="675"/>
</tileset>