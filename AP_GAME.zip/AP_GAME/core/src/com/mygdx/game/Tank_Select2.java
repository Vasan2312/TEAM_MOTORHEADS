package com.mygdx.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.Drawable;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

public class Tank_Select2 implements Screen {

    private TankStar game;
    private Texture img_entry_screen,img_entry_button,box;
    private Sprite sprite_entry_button;
    private Stage stage;
    private Skin skin;
    private TextButton textButton;
    private Texture buttonTexture,tank1,tank2,tank3,next;
    private Drawable drawable,drawable1,drawable2,drawable3,drawable4;
    private ImageButton imageButton,imageButton1,imageButton3,imageButton2,imageButton4;
    private boolean drawImage1 = false;
    private boolean drawImage2 = false;
    private boolean drawImage3 = false;

    Tank_Select2(TankStar game){
        this.game=game;


        stage = new Stage(new ScreenViewport());
        img_entry_screen = new Texture("tankSelect2.jpg");
        box = new Texture("box.jpg");


        tank1 = new Texture(Gdx.files.internal("Tank1.jpg"));
        drawable = new TextureRegionDrawable(new TextureRegion(tank1));
        imageButton = new ImageButton(drawable);
        imageButton.setBounds(15, 123, 360,202);

        tank2 = new Texture(Gdx.files.internal("Tank2.jpg"));
        drawable1 = new TextureRegionDrawable(new TextureRegion(tank2));
        imageButton1 = new ImageButton(drawable1);
        imageButton1.setBounds(387, 142, 334,176);

        tank3 = new Texture(Gdx.files.internal("Tank3.jpg"));
        drawable2 = new TextureRegionDrawable(new TextureRegion(tank3));
        imageButton2 = new ImageButton(drawable2);
        imageButton2.setBounds(707, 124, 330,210);

        next = new Texture(Gdx.files.internal("next.jpg"));
        drawable3 = new TextureRegionDrawable(new TextureRegion(next));
        imageButton3 = new ImageButton(drawable3);
        imageButton3.setBounds(1022, 5, 120,120);

        stage.addActor(imageButton);
        stage.addActor(imageButton1);
        stage.addActor(imageButton2);
        stage.addActor(imageButton3);
        Gdx.input.setInputProcessor(stage);
    }


    @Override
    public void show() {


    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0, 0, 0, 1);
        game.batch.begin();
        game.batch.draw(img_entry_screen, 0, 0);
        game.batch.end();
        stage.draw();


        if (drawImage1) {
            game.batch.begin();
            game.batch.draw( box, 10, 118);
            game.batch.end();
        }
        if (drawImage2) {
            game.batch.begin();
            game.batch.draw( box, 375, 118);
            game.batch.end();
        }
        if (drawImage3) {
            game.batch.begin();
            game.batch.draw( box, 720, 118);
            game.batch.end();
        }

        imageButton.addListener(new ClickListener(){
                                    @Override
                                    public void clicked(InputEvent event, float x, float y) {
                                        game.player_1_tank=1;
                                        drawImage1 = true;
                                        drawImage2 = false;
                                        drawImage3 = false;

                                    }
                                }
        )
        ;

        imageButton1.addListener(new ClickListener(){
                                     @Override
                                     public void clicked(InputEvent event, float x, float y) {
                                         game.player_1_tank=2;
                                         drawImage2 = true;
                                         drawImage1 = false;
                                         drawImage3 = false;

                                     }
                                 }
        )
        ;

        imageButton2.addListener(new ClickListener(){
                                     @Override
                                     public void clicked(InputEvent event, float x, float y) {
                                         game.player_1_tank=3;
                                         drawImage3 = true;
                                         drawImage1 = false;
                                         drawImage2 = false;

                                     }
                                 }
        )
        ;
        imageButton3.addListener(new ClickListener(){
                                     @Override
                                     public void clicked(InputEvent event, float x, float y) {
                                         game.setScreen(new GameScreen(game));
                                         stage.dispose();

                                     }
                                 }
        )
        ;

    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

        img_entry_screen.dispose();
        stage.dispose();
    }
}