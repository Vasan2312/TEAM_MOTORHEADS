package com.mygdx.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.Drawable;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
public class Setting1 implements Screen {

    private TankStar game;
    private Texture img_entry_screen,img_entry_button;
    private Sprite sprite_entry_button;
    private Stage stage;
    private Skin skin;
    private TextButton textButton;
    private Texture Sound_on,music_on,terms,vs_friend,resume,exit,Sound_off;
    private Drawable drawable,drawable1,drawable2,drawable3,drawable4;
    private ImageButton imageButton,imageButton1,imageButton3,imageButton2,imageButton4;

    Setting1(TankStar game){
        this.game=game;
        game.flag =1;
        stage = new Stage(new ScreenViewport());


        img_entry_screen = new Texture("Setting1.jpg");

        Sound_off = new Texture(Gdx.files.internal("Sound_off.jpg"));
        drawable = new TextureRegionDrawable(new TextureRegion(Sound_off));
        imageButton = new ImageButton(drawable);
        imageButton.setBounds(383, 287, 382,92);

        music_on= new Texture(Gdx.files.internal("music_on.jpg"));
        drawable2 = new TextureRegionDrawable(new TextureRegion(music_on));
        imageButton2 = new ImageButton(drawable2);
        imageButton2.setBounds(383, 170, 382,92);

        terms= new Texture(Gdx.files.internal("terms.jpg"));
        drawable3 = new TextureRegionDrawable(new TextureRegion(terms));
        imageButton3 = new ImageButton(drawable3);
        imageButton3.setBounds(383, 56, 382,92);

        exit= new Texture(Gdx.files.internal("CrossGreen.jpg"));
        drawable4 = new TextureRegionDrawable(new TextureRegion(exit));
        imageButton4 = new ImageButton(drawable4);
        imageButton4.setBounds(718, 414, 58,58);

        stage.addActor(imageButton);
        stage.addActor(imageButton2);
        stage.addActor(imageButton3);
        stage.addActor(imageButton4);

        Gdx.input.setInputProcessor(stage);
    }


    @Override
    public void show() {


    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0, 0, 0, 1);
        game.batch.begin();
        game.batch.draw(img_entry_screen, 0, 0);
        game.batch.end();
        stage.draw();

        imageButton4.addListener(new ClickListener(){
                                     @Override
                                     public void clicked(InputEvent event, float x, float y) {
                                         game.setScreen(new MainMenu(game));
                                         stage.dispose();
                                     }
                                 }
        )
        ;
        imageButton.addListener(new ClickListener(){
                                    @Override
                                    public void clicked(InputEvent event, float x, float y) {
                                        game.setScreen(new Setting(game));
                                        stage.dispose();
                                    }
                                }
        )
        ;
        imageButton2.addListener(new ClickListener(){
                                     @Override
                                     public void clicked(InputEvent event, float x, float y) {
                                         game.setScreen(new Setting3(game));
                                         stage.dispose();
                                     }
                                 }
        )
        ;
        imageButton3.addListener(new ClickListener(){
                                     @Override
                                     public void clicked(InputEvent event, float x, float y) {
                                         URI uri = null;
                                         try {
                                             uri = new URI("https://playgendary.com/en/playgendary-gmbh-privacy-policy");
                                         } catch (URISyntaxException e) {
                                             throw new RuntimeException(e);
                                         }
                                         try {
                                             java.awt.Desktop.getDesktop().browse(uri);
                                         } catch (IOException e) {
                                             throw new RuntimeException(e);
                                         }
                                         stage.dispose();
                                     }
                                 }
        )
        ;
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        img_entry_screen.dispose();
        stage.dispose();
    }
}